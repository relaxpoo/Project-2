package com.pooja.project2_backend;


import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.pooja.dao.UserDao;
import com.pooja.model.User;

public class UserTest {
 
	private static AnnotationConfigApplicationContext context=null;
	private static UserDao userDAO=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		context=new AnnotationConfigApplicationContext();
		context.scan("com.pooja");
		context.refresh();
		userDAO=(UserDao)context.getBean("userDao");
	}

	@Test
	public void testRegistration() {
		User user=new User();
		user.setEmail("bhanoosingh2@gmail.com");
		user.setFirstname("Bhanoo");
		user.setLastname("Singh");
		user.setOnline(false);
		user.setPassword("123456");
		user.setPhonenumber("8960992608");
		user.setRole("USER");
		
		assertTrue("Fail to insert data",userDAO.registration(user));
		
		/*assertTrue("Fail to add user",userDAO.registration(user));*/
		
	}


	@Test
	public void testIsEmailValid() {
		fail("Not yet implemented");
	}

	@Test
	public void testLogin() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUser() {
		fail("Not yet implemented");
	}

}
