package com.pooja.dao;

import com.pooja.model.ProfilePicture;

public interface ProfilePictureDao {
	void upload(ProfilePicture profilePicture);
	ProfilePicture getProfilePic(String email);
	}
