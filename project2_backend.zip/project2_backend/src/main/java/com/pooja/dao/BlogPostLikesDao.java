package com.pooja.dao;

import com.pooja.model.BlogPost;
import com.pooja.model.BlogPostLikes;

public interface BlogPostLikesDao {
	BlogPostLikes hasUserLikedPost(int postId,String email);
	BlogPost updateLikes(int postId,String email);
}