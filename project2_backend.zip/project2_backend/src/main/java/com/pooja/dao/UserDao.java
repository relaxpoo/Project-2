package com.pooja.dao;

import com.pooja.model.User;

public interface UserDao {
	boolean registration(User user);
	 boolean isEmailValid(String email);
	 User login(User user);
	 void update(User user);
	User getUser(String email);
	}
