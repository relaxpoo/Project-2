app.controller('ChatCtrl', function($scope,$rootScope,chatService,$http)
{
	$scope.messages;
	
	chatService.receive().then(function(message)
			{
				$scope.messages=message.data;
				
				});
	
	$scope.message="";
	$scope.max=250;

	$scope.addMessage=function()
	{
		/*alert($scope.email);*/
		chatService.send($rootScope.loggedInUser.firstname+":" +$scope.message+"\nEmail:"+$rootScope.loggedInUser.email);
		$scope.message="";
		location.reload();
	};

	

});