package com.pooja.dao;

import java.util.List;

import com.pooja.model.BlogPost;

public interface BlogPostDao {
	void addBlogPost(BlogPost blogPost);
	List<BlogPost> getBlogs(boolean approved);//0 or 1
	BlogPost getBlogById(int id);
	}
