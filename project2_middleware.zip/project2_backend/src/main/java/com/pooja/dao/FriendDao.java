package com.pooja.dao;

import java.util.List;

import com.pooja.model.Friend;
import com.pooja.model.User;

public interface FriendDao {
	List<User> listOfSuggestedUsers(String email);
	void addFriendRequest(Friend friend);
	List<Friend> getAllPendingRequests(String email);//loggedin user id
	void updateFriendRequest(Friend friend);
	List<User> listOfFriends(String email);
}