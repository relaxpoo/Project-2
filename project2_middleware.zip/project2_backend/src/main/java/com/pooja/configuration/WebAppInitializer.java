package com.pooja.configuration;

import javax.servlet.ServletRegistration;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
//similar to web.xml file configuration
public class WebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {
 // Dispatcher servlet is instantiated
	@Override
	protected void customizeRegistration(ServletRegistration.Dynamic registration) {
		System.out.println("customizeRegistration");
		registration.setInitParameter("dispatchOptionsRequest", "true");
		registration.setAsyncSupported(true);
	}
	
	@Override
	protected Class<?>[] getRootConfigClasses() {
		//creates beans for DataSource, Session Factory and HybernateTransactionManager
		return new Class[]{DBConfiguration.class};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		//Enable Web MVC,Handler Mapping, Scans all the components in the base package "com.niit"
		return new Class[]{WebConfig.class};
	}

	//Forwards all the incoming requests to DispatcherServlet by specifying the url pattern as '/'
	@Override
	protected String[] getServletMappings() {
		return new String[]{"/"};
	}

}